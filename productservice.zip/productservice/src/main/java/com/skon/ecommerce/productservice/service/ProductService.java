package com.skon.ecommerce.productservice.service;

import com.skon.ecommerce.productservice.entity.Product;
import com.skon.ecommerce.productservice.repository.ProductRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    ProductRespository productRespository;

   public List<Product> getProducts() {
       List<Product> productsList = new ArrayList<>();
       try {
           productsList = productRespository.findAll();
       }catch(Exception e){
           e.printStackTrace();
       }
       return productsList;
   }

   public Product createProduct(Product product){
       try{
           productRespository.save(product);
       }catch(Exception e){
            e.printStackTrace();
       }

       return product;
   }

   public Product updateProduct(Product product){
       productRespository.save(product);

       return product;
   }

   public Product getProductById(Integer id){
       Optional<Product> product = productRespository.findById(id);

       return product.get();
   }
}
