package com.skon.ecommerce.orderservice.service;

import com.skon.ecommerce.orderservice.model.ProductMapper;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("PRODUCT_SERVICE")
public interface ProductService {

    @GetMapping("/products/getProduct/{id}")
    public ResponseEntity<ProductMapper> getProductById(@PathVariable Integer id);
}
