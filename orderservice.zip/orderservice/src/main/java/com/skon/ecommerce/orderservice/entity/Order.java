package com.skon.ecommerce.orderservice.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "order")
@Data
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "customer_name")
    private String customerName;
    private Date orderDate;

    @ElementCollection
    @Column(name ="product_ids")
    private List<Integer> productIds;

    public Order(int id, String customerName, List<Integer> productIds, Date orderDate) {
        this.id = id;
        this.customerName = customerName;
        this.productIds = productIds;
        this.orderDate = orderDate;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", customerName='" + customerName + '\'' +
                ", productIds=" + productIds +
                ", orderDate=" + orderDate +
                '}';
    }
}
