package com.skon.ecommerce.orderservice.model;

import lombok.Data;

@Data
public class ProductMapper {

    private int id;
    private String productName;
    private String description;
    private Double price;
    private String imageUrl;

    public ProductMapper(int id, String productName, String description, Double price, String imageUrl) {
        this.id = id;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.imageUrl = imageUrl;
    }
}
